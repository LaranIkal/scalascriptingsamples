

println("Hello, Welcome to Scala Script.....!!!!!")

Utils.PrintSomething
System.exit(1)

